package dota2.game.mod.blocks;

import net.minecraft.block.BlockFurnace;

public class BlockShop extends BlockFurnace {

	protected BlockShop(int par1, boolean par2) {
		super(par1, par2);
	
	}
	
}
