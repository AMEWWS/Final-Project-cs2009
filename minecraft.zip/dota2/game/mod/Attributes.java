package dota2.game.mod;

public enum Attributes {

	STRENGTH,
	INTELLECT,
	AGILITY
}
