package dota2.game.mod.items;

import net.minecraft.item.Item;

public class ItemBase extends Item {

	public ItemBase(int par1) {
		super(par1);
		 
	}

}
